<template>
    <h1>Home!!</h1>
</template>

<script lang="ts">
    export default {

    }
</script>

<style scoped>

</style>